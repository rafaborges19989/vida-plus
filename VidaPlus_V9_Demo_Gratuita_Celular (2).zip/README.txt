VIDA+ V9 — DEMONSTRAÇÃO GRATUITA

Esta versão foi feita para você mostrar o conceito no celular sem pagar servidor.

IMPORTANTE:
- Os dados são fictícios.
- Não conecte banco real.
- Não coloque senhas bancárias nesta demonstração.
- O botão "Conectar banco" apenas simula o fluxo.

COMO USAR:
1. Extraia o ZIP.
2. Abra index.html no navegador.
3. No celular, se o navegador oferecer "Adicionar à tela inicial", use essa opção.
4. Para compartilhar com outras pessoas pela internet sem pagar hospedagem, você pode colocar esta pasta em um serviço de hospedagem estática gratuita, como GitHub Pages. O arquivo não contém segredos.

O QUE MOSTRAR:
- Dashboard
- Gastos
- Dívidas e parcelas
- Cofres
- Conectar banco (simulação)
- Menu do produto

PRÓXIMA FASE:
login real, banco PostgreSQL, Pluggy Connect, sincronização, WhatsApp, pagamentos, Android/iOS e painel proprietário.
